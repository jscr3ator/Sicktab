function resetTime() {
	var today = new Date();
	if (today.getHours() > 12)
	{
		var time = today.getHours()-12 + ":" + today.getMinutes()
		document.getElementById("time").innerText = time;
	}
	else{
		if (today.getSeconds() < 10){
			var time = today.getHours() + ":" + today.getMinutes() + ":0" +today.getSeconds()
		}else{
			var time = today.getHours() + ":" + today.getMinutes() + ":0" + today.getSeconds()
		}
		document.getElementById("time").innerText = time;
	}
}

setInterval(resetTime, 100)

var today = new Date();
var date = (today.getMonth()+1)+'/'+today.getDate()+'/'+today.getFullYear().toString().substr(-2);
document.getElementById("date").innerText = date;

setInterval(resetTime, 100)